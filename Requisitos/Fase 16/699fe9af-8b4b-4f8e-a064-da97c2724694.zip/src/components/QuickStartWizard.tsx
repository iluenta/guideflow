import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  Home,
  ListChecks,
  MapPin,
  MessageCircle } from
'lucide-react';
import { Button } from './ui/Button';
import { BasicosStep } from './steps/BasicosStep';
import { TuCasaStep } from './steps/TuCasaStep';
import { RecomendacionesStep } from './steps/RecomendacionesStep';
import { FaqsExpressStep } from './steps/FaqsExpressStep';
interface QuickStartWizardProps {
  onComplete: () => void;
  onBack: () => void;
}
export function QuickStartWizard({
  onComplete,
  onBack
}: QuickStartWizardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [direction, setDirection] = useState(0);
  // Form State
  const [formData, setFormData] = useState({
    basicos: {
      propertyName: '',
      address: '',
      propertyType: 'apartment',
      accessType: 'smartlock',
      accessCode: '',
      wifiName: '',
      wifiPass: '',
      checkInTime: '15:00',
      checkOutTime: '11:00'
    },
    tuCasa: {
      inventoryMode: 'manual' as const,
      inventoryItems: ['wifi', 'tv', 'kitchen', 'towels', 'linens']
    },
    recomendaciones: {
      hasRecommendations: null as boolean | null,
      selectedPlaces: []
    },
    faqs: {
      faqs: [
      {
        id: 'parking',
        question: '¿Hay parking disponible?',
        answer: '',
        isActive: true,
        icon: '🅿️'
      },
      {
        id: 'pets',
        question: '¿Se admiten mascotas?',
        answer: '',
        isActive: true,
        icon: '🐾'
      },
      {
        id: 'noise',
        question: '¿Hay normas de ruido?',
        answer: '',
        isActive: false,
        icon: '🔊'
      },
      {
        id: 'trash',
        question: '¿Dónde dejo la basura?',
        answer: '',
        isActive: true,
        icon: '🗑️'
      },
      {
        id: 'keys',
        question: '¿Dónde dejo las llaves al salir?',
        answer: '',
        isActive: true,
        icon: '🔑'
      },
      {
        id: 'emergency',
        question: '¿A quién llamo en caso de emergencia?',
        answer: '',
        isActive: false,
        icon: '🆘'
      }]

    }
  });
  const steps = [
  {
    id: 'basicos',
    label: 'Básicos',
    icon: Home,
    time: '~1 min'
  },
  {
    id: 'tucasa',
    label: 'Tu Casa',
    icon: ListChecks,
    time: '~2 min'
  },
  {
    id: 'zona',
    label: 'Zona',
    icon: MapPin,
    time: '~1 min'
  },
  {
    id: 'faqs',
    label: 'FAQs',
    icon: MessageCircle,
    time: '~1 min'
  }];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setDirection(1);
      setCurrentStep((prev) => prev + 1);
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    } else {
      onComplete();
    }
  };
  const handleBack = () => {
    if (currentStep > 0) {
      setDirection(-1);
      setCurrentStep((prev) => prev - 1);
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    } else {
      onBack();
    }
  };
  const updateFormData = (section: keyof typeof formData, data: any) => {
    setFormData((prev) => ({
      ...prev,
      [section]: {
        ...prev[section],
        ...data
      }
    }));
  };
  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <BasicosStep
            data={formData.basicos}
            onChange={(d) => updateFormData('basicos', d)} />);


      case 1:
        return (
          <TuCasaStep
            data={formData.tuCasa}
            onChange={(d) => updateFormData('tuCasa', d)} />);


      case 2:
        return (
          <RecomendacionesStep
            data={formData.recomendaciones}
            onChange={(d) => updateFormData('recomendaciones', d)} />);


      case 3:
        return (
          <FaqsExpressStep
            data={formData.faqs}
            onChange={(d) => updateFormData('faqs', d)} />);


      default:
        return null;
    }
  };
  const progress = (currentStep + 1) / steps.length * 100;
  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header & Stepper */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-30">
        <div className="h-1 bg-gray-100 w-full">
          <motion.div
            className="h-full bg-primary"
            initial={{
              width: 0
            }}
            animate={{
              width: `${progress}%`
            }}
            transition={{
              duration: 0.5
            }} />

        </div>

        <div className="max-w-3xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-6">
            <button
              onClick={onBack}
              className="text-text-secondary hover:text-text-primary flex items-center gap-1 text-sm font-medium">

              <ArrowLeft className="w-4 h-4" /> Volver
            </button>
            <div className="text-center">
              <h1 className="text-xl font-bold text-text-primary">
                ⚡ Crea tu Guía en 5 Minutos
              </h1>
              <p className="text-xs text-text-secondary hidden md:block">
                Solo lo esencial para publicar hoy. Podrás enriquecer tu guía
                después.
              </p>
            </div>
            <div className="w-16"></div> {/* Spacer for centering */}
          </div>

          {/* Stepper */}
          <div className="flex items-center justify-between relative">
            {/* Connecting Line */}
            <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-gray-100 -z-10 -translate-y-1/2 hidden md:block" />

            {steps.map((step, index) => {
              const Icon = step.icon;
              const isCompleted = index < currentStep;
              const isCurrent = index === currentStep;
              return (
                <div
                  key={step.id}
                  className="flex flex-col items-center bg-white px-2">

                  <div
                    className={`
                      w-8 h-8 md:w-10 md:h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300
                      ${isCompleted ? 'bg-primary border-primary text-white' : ''}
                      ${isCurrent ? 'border-primary text-primary ring-4 ring-primary/10 scale-110' : ''}
                      ${!isCompleted && !isCurrent ? 'border-gray-200 text-gray-300' : ''}
                    `}>

                    {isCompleted ?
                    <Check className="w-5 h-5" /> :

                    <Icon className="w-4 h-4 md:w-5 md:h-5" />
                    }
                  </div>
                  <div className="text-center mt-2 hidden md:block">
                    <p
                      className={`text-xs font-bold ${isCurrent ? 'text-primary' : 'text-gray-400'}`}>

                      {step.label}
                    </p>
                    <span className="text-[10px] text-gray-400 bg-gray-50 px-1.5 py-0.5 rounded-full mt-1 inline-block">
                      {step.time}
                    </span>
                  </div>
                </div>);

            })}
          </div>

          {/* Mobile Step Label */}
          <div className="md:hidden text-center mt-2">
            <span className="text-sm font-bold text-primary">
              {steps[currentStep].label}
            </span>
            <span className="text-xs text-gray-400 ml-2">
              {steps[currentStep].time}
            </span>
          </div>
        </div>
      </div>

      {/* Content */}
      <main className="flex-1 w-full max-w-3xl mx-auto px-4 py-8 pb-24">
        <AnimatePresence mode="wait" custom={direction}>
          <motion.div
            key={currentStep}
            custom={direction}
            initial={{
              x: direction * 20,
              opacity: 0
            }}
            animate={{
              x: 0,
              opacity: 1
            }}
            exit={{
              x: direction * -20,
              opacity: 0
            }}
            transition={{
              duration: 0.3
            }}>

            {renderStep()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Bottom Nav */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 z-20">
        <div className="max-w-3xl mx-auto flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={handleBack}
            disabled={currentStep === 0}
            className={currentStep === 0 ? 'invisible' : ''}>

            Anterior
          </Button>

          <div className="flex items-center gap-4">
            {(currentStep === 1 || currentStep === 2) &&
            <button
              onClick={handleNext}
              className="text-sm font-medium text-text-secondary hover:text-text-primary hidden md:block">

                Sáltalo por ahora →
              </button>
            }
            <Button
              onClick={handleNext}
              className="min-w-[140px]"
              rightIcon={<ArrowRight className="w-4 h-4" />}>

              {currentStep === steps.length - 1 ? 'Finalizar' : 'Continuar'}
            </Button>
          </div>
        </div>
      </div>
    </div>);

}