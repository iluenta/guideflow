import React from 'react';
import { PropertyWizard } from './components/PropertyWizard';
export function App() {
  return <PropertyWizard />;
}